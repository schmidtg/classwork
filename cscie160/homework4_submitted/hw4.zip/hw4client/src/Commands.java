package cscie160.hw4;

public enum Commands 
{
    DEPOSIT, WITHDRAW, BALANCE
}
